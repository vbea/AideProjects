package com.mycompany.myapp16;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.hardware.*;
import android.graphics.drawable.*;
import android.util.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity
{//声明传感器管理器对象
  SensorManager sm;
  //声明传感器对象
  Sensor as;
  //声明自定义视图对象
   String str="再接再厉!";
	MyView mv;
	static int h,w,xx=20;
	int f,o,s=2;
	SharedPreferences sp;
	boolean start=false,time=false;
	float x,y;
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		requestWindowFeature(1);
		//隐藏状态栏
		getWindow().setFlags(1024,1024);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.main);
		DisplayMetrics  dm = new DisplayMetrics(); 
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		w = dm.widthPixels;
		h = dm.heightPixels;
		//实例化视图对象
		mv=new MyView(this);
		//设定自定义视图
		setContentView(mv);
		if(w>400&h>800){
			xx=40;
		}
		//实例化传感器管理器对象
		sm=(SensorManager)getSystemService(Service.SENSOR_SERVICE);
		//实例化加速度传感器对象
		as=sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		//为传感器管理器注册监听器
		sm.registerListener(new listener(),as,1);
		sp=getSharedPreferences("save",MODE_PRIVATE);
		//获取保存的内容
		f=sp.getInt("int",f);
	}
	class listener implements SensorEventListener
	{
		public void onSensorChanged(SensorEvent p1)
		{
			if(start==true){
				//时间为0时处理的代码
				if(mv.Time==0){
					ylc();
					
				}else{
					//两圆重合时的代码
				if(((w/2+0.8>=mv.x)&(w/2-0.8<=mv.x))&((h/2+0.8>=mv.y)&(h/2-0.8<=mv.y))){
					mv.av++;
					mv.Time+=7;
					s++;
					mv.x=new Random().nextInt(w);
					mv.y=new Random().nextInt(h);
					mv.invalidate();
				}
			//传感器数据发生改变执行
			if(false==time){
				time=true;
			uiHandler2.sendEmptyMessageDelayed(1,1000);
			}
			x=p1.values[0];
			y=p1.values[1];
			if((mv.x<-xx||mv.x>w+xx)||(mv.y<-xx||mv.y>h+xx)){
				ylc();
			}
				mv.x-=s*x;
				mv.y+=s*y;
			
			//重绘视图
			mv.invalidate();
		}}}
		public void onAccuracyChanged(Sensor p1, int p2)
		{//传感器精度发生改变执行

		}
	}
	//在这个方法内添加菜单
	public boolean
	//数值1是组，2是id，3是位置,4是内容
	onCreateOptionsMenu(Menu menu){
		//添加关于菜单项
		menu.add(1,1,2,"关于").setIcon(android.R.drawable.ic_dialog_info);
		//添加退出菜单项
		menu.add(1,2,3,"退出").setIcon(android.R.drawable.ic_lock_power_off);
		menu.add(1,3,1,"开始");
		//返回真
		return true;}

	//菜单项被点击的事件处理
	public boolean onOptionsItemSelected(MenuItem item){
		//关于菜单项被点击
		if(item.getItemId()==1){
          helpylc();
		}
	
		//退出菜单项被点击
		else if(item.getItemId()==2){
			//销毁
			finish();
			//完全退出
			android.os.Process.killProcess(android.os.Process.myPid());
			//开始菜单项被点击
		}else if(item.getItemId()==3){
			start=true;
			o=1;
			s=1;
			
		}
		//返回假
		return false;
	}
	public void onBackPressed(){
		Toast.makeText(this,"最高分为："+f,0).show();
		}
	private Handler uiHandler2 = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			if(o!=3){
			mv.Time--;}
			uiHandler2.sendEmptyMessageDelayed(1,1000);
		};
	};
	
	public void helpylc(){
	AlertDialog.Builder Alert1= new AlertDialog.Builder(this).setTitle("关于&帮助").setMessage("点击<开始>按钮开始游戏，返回键查看最高分数。黑球里面是分数，绿球是时间，屏幕边缘会掉落，做好平衡，把黑球与绿球重合，重合一次分数加一，时间加8秒，速度倍数增加，掌握平衡吧！\n邮箱:1205125324@qq.com");
	    Alert1.show();
	}
	public void ylc(){
		if(mv.av>f){
			str="恭喜你破纪录了！";
			Toast.makeText(MainActivity.this,str,Toast.LENGTH_LONG).show();
			f=mv.av;
			//保存数据
			sp.edit().putInt("int",f).commit();
		}
		str="再接再厉！";
		Toast.makeText(MainActivity.this,str,Toast.LENGTH_LONG).show();
		mv.x=20;
		mv.y=20;
		o=3;
		start=false;
		time=true;
		mv.Time=30;
		mv.av=0;
		mv.invalidate();
	}
}
