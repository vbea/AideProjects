package com.mycompany.myapp16;

import android.content.*;
import android.graphics.*;
import android.view.*;

public class MyView extends View
{//构造函数
	MyView(Context context){
		super(context);
}
    static int Time=30;
	static int av=0;
	float x=20,y=20;
	Paint p=new Paint();
	//绘图函数
	public void onDraw(Canvas canvas)
	{
		
		canvas.drawColor(Color.WHITE);
		p.setColor(Color.GREEN);
		canvas.drawCircle(MainActivity.w/2,MainActivity.h/2,MainActivity.xx,p);
		p.setColor(Color.RED);
		p.setTextSize(25);
		canvas.drawText(Time+"",MainActivity.w/2-13,MainActivity.h/2+9,p);
		p.setColor(Color.BLACK);
		canvas.drawCircle(x,y,MainActivity.xx,p);
		p.setColor(Color.RED);
		p.setTextSize(25);
		canvas.drawText(av+"",x-7,y+7,p);
		super.onDraw(canvas);
	}
	
}
