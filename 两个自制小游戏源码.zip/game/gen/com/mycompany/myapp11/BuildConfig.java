/** Automatically generated file. DO NOT MODIFY */
package com.mycompany.myapp11;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}