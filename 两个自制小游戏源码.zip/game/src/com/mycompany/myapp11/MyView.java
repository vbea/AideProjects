package com.mycompany.myapp11;

import android.content.*;
import android.graphics.*;
import android.view.*;
import android.media.*;
import android.content.res.*;
import java.io.*;
import java.util.*;

public class MyView extends View
{//构造函数
	MyView(Context context){
		super(context);
}
    Bitmap b1=null;
	static int av=0;//时间
	//为所有小圆声明一个随机出生坐标
	static float up_number = new Random().nextInt(MainActivity.w);
	static float under_number = new Random().nextInt(MainActivity.w);
	static float left_number = new Random().nextInt(MainActivity.h);
	static float right_number = new Random().nextInt(MainActivity.h);
	//为所有小圆赋值初始坐标
	static float up_x[]={up_number,up_number,up_number,up_number},up_y[]={-5,-5,-5,-5};
	static float under_x[]={under_number,under_number,under_number,under_number},under_y[]={MainActivity.h+5,MainActivity.h+5,MainActivity.h+5,MainActivity.h+5};
	static float left_x[]={-5,-5,-5,-5},left_y[]={left_number,left_number,left_number,left_number};
	static float right_x[]={MainActivity.w+5,MainActivity.w+5,MainActivity.w+5,MainActivity.w+5},right_y[]={right_number,right_number,right_number,right_number};
	//获取飞机图片
	Bitmap zj=resizeImage(getImgForAssets("zj.png"), 25, 17);
	//初始化飞机的坐标
	static float x=(MainActivity.w/2),y=(MainActivity.h/2);
	//声明并实例化笔刷对象
	Paint p=new Paint();
	//绘图函数
	public void onDraw(Canvas canvas)
   {
		canvas.drawColor(Color.WHITE);
		p.setColor(Color.BLACK);
		//绘制所有小圆
		canvas.drawCircle(up_x[0],up_y[0],5,p);
	    canvas.drawCircle(under_x[0],under_y[0],5,p);
	    canvas.drawCircle(left_x[0],left_y[0],5,p);
	    canvas.drawCircle(right_x[0],right_y[0],5,p);
	   canvas.drawCircle(up_x[1],up_y[1],5,p);
	   canvas.drawCircle(under_x[1],under_y[1],5,p);
	   canvas.drawCircle(left_x[1],left_y[1],5,p);
	   canvas.drawCircle(right_x[1],right_y[1],5,p);
	    canvas.drawCircle(up_x[2],up_y[2],5,p);
	    canvas.drawCircle(under_x[2],under_y[2],5,p);
	    canvas.drawCircle(left_x[2],left_y[2],5,p);
	    canvas.drawCircle(right_x[2],right_y[2],5,p);
	   canvas.drawCircle(up_x[3],up_y[3],5,p);
	   canvas.drawCircle(under_x[3],under_y[3],5,p);
	   canvas.drawCircle(left_x[3],left_y[3],5,p);
	   canvas.drawCircle(right_x[3],right_y[3],5,p);
	   //绘制飞机图片
		canvas.drawBitmap(zj,x,y,p);
		//绘制显示时间的文字
		p.setColor(Color.RED);
		p.setTextSize(25);
		canvas.drawText(av+"",MainActivity.w/2-13,20,p);
		super.onDraw(canvas);
		}
	//下面是封装的获取图片和缩放图片大小的方法
	/**
	   * 图片缩放
	   * @param bitmap
	   * @param w
	   * @param h
	   * @return
	 */
	public Bitmap resizeImage(Bitmap bitmap, int w, int h) {
		return resizeImage(bitmap,(float)w, (float)h);
	}
	public Bitmap resizeImage(Bitmap bitmap, float w, float h) {
    Bitmap BitmapOrg = bitmap;
    int width = BitmapOrg.getWidth();
    int height = BitmapOrg.getHeight();
    float scaleWidth = w/width;
    float scaleHeight =h/height;
    Matrix matrix = new Matrix();
    matrix.postScale(scaleWidth, scaleHeight);
    return Bitmap.createBitmap(BitmapOrg, 0, 0, width,height, matrix, true);
	}
	/**
	 * 获取assets目录下的图片资源
	 * @param fpath
	 * @return
	 */
	public Bitmap getImgForAssets(String fpath){
		Bitmap b1=null;
		AssetManager am = getResources().getAssets();  
		try {
			InputStream is = am.open(fpath);  
			b1 = BitmapFactory.decodeStream(is);  
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return b1;
	}
	
}
