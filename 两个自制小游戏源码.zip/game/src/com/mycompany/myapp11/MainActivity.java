package com.mycompany.myapp11;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.hardware.*;
import android.graphics.drawable.*;
import android.util.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity
{
	SharedPreferences sp;//声明保存数据
	//声明屏幕的宽，高，最高分，和小圆最大速度加成
	static int w,h,f,ylc=0;
	//声明两个二维数组来存放每个小圆的随机出生坐标
	static int wx[][]={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}},hy[][]={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	//声明手指x，y和图片的x，y
	float x,y,x1,y1;
	static MyView mv;
	boolean end=false;//游戏未结束状态
	boolean start=false;//游戏未开始状态
	//声明一个二维数组存放每个小圆是否复位
	boolean av[][]={{false,false,false,false},{false,false,false,false},{false,false,false,false},{false,false,false,false}};
	boolean UI=false;//用来判断是否执行过小圆移动方法
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
		//隐藏状态栏和标题栏
		requestWindowFeature(1);
		getWindow().setFlags(1024,1024);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		//设置显示一个XML布局用来获取屏幕宽度
		setContentView(R.layout.main);
		//获取屏幕宽度
		DisplayMetrics  dm = new DisplayMetrics(); 
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		w = dm.widthPixels;
		h = dm.heightPixels;
		//实例化视图对象
		mv=new MyView(this);
		//设定自定义视图
		setContentView(mv);
		//获取保存的内容
		sp=getSharedPreferences("save",MODE_PRIVATE);
	    f=sp.getInt("int",f);	
		
		}
	//屏幕触摸事件触发方法
	public  boolean onTouchEvent(MotionEvent event)
	{//判断游戏是否开始或结束，游戏已经开始且未结束才会执行下面的代码
		if((start==true)&(end==false)){
		//点击屏幕触发的事件，这里是看作手指接触到屏幕还未滑动
		if(event.getAction()==0){
		//获取手指的坐标用来实现手指与飞机的相对运动
			x=event.getX();
			y=event.getY();
			x1=x;
			y1=y;
		}
		//手指在屏幕滑动执行的方法
		if(event.getAction()==2){
			//获取滑动时手指的坐标
			x=event.getX();
			y=event.getY();
			//实现手指与图片的相对运动
			if(x<x1){
				mv.x-=x1-x;
			}else if(x>x1){
				mv.x+=x-x1;
			}if(y<y1){
				mv.y-=y1-y;
			}else if(y>y1){
				mv.y+=y-y1;
			}
			x1=x;
			y1=y;
			//让飞机不能跑出屏幕的代码
			if(mv.x<0){
				mv.x=0;
			}if(mv.x>w-20){
				mv.x=w-20;
			}if(mv.y<0){
				mv.y=0;
			}if(mv.y>h-20){
				mv.y=h-20;
			}
			//重绘视图
			mv.invalidate();
		}}
		//返回真才能一直监听触屏事件
		return true;
	}
	//在这个方法内添加菜单
	public boolean
	//数值1是组，2是id，3是位置,4是内容
	onCreateOptionsMenu(Menu menu){
		//添加关于菜单项
		menu.add(1,1,2,"关于").setIcon(android.R.drawable.ic_dialog_info);
		//添加退出菜单项
		menu.add(1,2,3,"退出").setIcon(android.R.drawable.ic_lock_power_off);
		menu.add(1,3,1,"开始");
		//返回真
		return true;}

	//菜单项被点击的事件处理
	public boolean onOptionsItemSelected(MenuItem item){
	//关于菜单项被点击
		if(item.getItemId()==1){
            helpylc();
		}
	//退出菜单项被点击
		else if(item.getItemId()==2){
			//销毁
			finish();
			//完全退出
			android.os.Process.killProcess(android.os.Process.myPid());
	//开始菜单项被点击
		}else if(item.getItemId()==3){
			if(start==false){//判断是否已经开始游戏
			end=false;
			start=true;
		//执行小圆移动方法，只执行一次
			if(UI==false){
				UI=true;
			uiHandler.sendEmptyMessageDelayed(1,1000);
		    uiHandler1.sendEmptyMessageDelayed(1,25);
			uiHandler2.sendEmptyMessageDelayed(1,25);
			uiHandler3.sendEmptyMessageDelayed(1,25);
			uiHandler4.sendEmptyMessageDelayed(1,25);
			}}
		}
		//返回假
		return false;
	}
	//返回键事件
	public void onBackPressed(){
		Toast.makeText(this,"你最多坚持了"+f+"秒",0).show();
		}
	//计时事件
	private Handler uiHandler = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			//游戏未结束时执行
			if(end==false){
			mv.av++;//时间+1
			//每5秒加1小圆的最大速度
			switch(mv.av/5){
				case 1:
					ylc++;
					break;
				case 2:
					ylc++;
			    	break;
				case 3:
					ylc++;
					break;
				case 4:
					ylc++;
					break;
				case 5:
					ylc++;
					break;
				case 6:
					ylc++;
					break;
				case 7:
					ylc++;
					break;
				case 8:
					ylc++;
					break;
				case 9:
					ylc++;
					break;
			}
			mv.invalidate();}
			uiHandler.sendEmptyMessageDelayed(1,1000);
		};
	};
	//上面的小圆
	private Handler uiHandler1 = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			draw(0);
			//判断是否碰撞
			for(int i=0;i<4;i++){
			if(ishit(mv.x+7,mv.y+10,20,10,mv.up_x[i],mv.up_y[i],10,10)){
				evil();}}
			uiHandler1.sendEmptyMessageDelayed(1,25);
	};
	};
	//下面的小圆
	private Handler uiHandler2 = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			draw(1);
			//判断是否碰撞
			for(int i=0;i<4;i++){
			if(ishit(mv.x+7,mv.y+10,20,10,mv.under_x[i],mv.under_y[i],10,10)){
				evil();}}
			uiHandler2.sendEmptyMessageDelayed(1,25);

		};
	};
	//左边的小圆
	private Handler uiHandler3 = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			draw(2);
			//判断是否碰撞
			for(int i=0;i<4;i++){
			if(ishit(mv.x+7,mv.y+10,20,10,mv.left_x[i],mv.left_y[i],10,10)){
				evil();}}
			uiHandler3.sendEmptyMessageDelayed(1,25);
		};
	};
	//右边的小圆
	private Handler uiHandler4 = new Handler() {
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			draw(3);
			//判断是否碰撞
			for(int i=0;i<4;i++){
			if(ishit(mv.x+7,mv.y+10,20,10,mv.right_x[i],mv.right_y[i],10,10)){
				evil();}}
			uiHandler4.sendEmptyMessageDelayed(1,25);
		};
	};
	//显示帮助
	public void helpylc(){
	AlertDialog.Builder Alert1= new AlertDialog.Builder(this).setTitle("关于&帮助").setMessage("活下去……");
	    Alert1.show();
	}
	//飞机被撞时
	public void evil(){
		//现在时间大于保存的时间
		if(mv.av>f){
			//保存大的数值
			f=mv.av;
		sp.edit().putInt("int",f).commit();
		Toast.makeText(this,"恭喜你"+f+"秒破纪录了！",0).show();
	}else{
		Toast.makeText(this,"你坚持了"+mv.av+"秒",0).show();
	}
	//初始化数值坐标
	end=true;//游戏结束状态
	start=false;//未开始状态
	//所有小圆复位
	for(int ii=0;ii<=3;ii++){
		mv.up_x[ii]=0;
		mv.up_y[ii]=-5;
		mv.under_x[ii]=w;
		mv.under_y[ii]=h+5;
		mv.left_x[ii]=-5;
		mv.left_y[ii]=0;
		mv.right_x[ii]=w+5;
		mv.right_y[ii]=h;
	}
	    //飞机复位
	    mv.x=w/2;
		mv.y=h/2;
	    mv.av=0;//时间清零
		ylc=0;//加成速度清零
		mv.invalidate();
	}
	//判断是否碰撞
	public boolean ishit(float imgx,float imgy,int imgw,int imgh,float x,float y,int width,int height){//是否发生碰撞
		if((imgx==x&&imgy==y)||((imgy+imgh>y&&imgy+imgh<y+height||imgy<y+height&&imgy>=y)&&imgx<x+width&&imgx+imgw>x)){
			return true;
		}
		return false;
	}
	//小圆运动
	public void draw(int j){
				for(int i=0;i<4;i++){
					if(end==false){//游戏是否结束
						if(av[j][i]==false){//每个圆的移动速度，每轮执行一次
							av[j][i]=true;
							if(j<2){
							wx[j][i] =new Random().nextInt(11)-6;
							hy[j][i] =new Random().nextInt(ylc+5)+2;
							}else{
							wx[j][i] =new Random().nextInt(ylc+5)+2;
							hy[j][i] =new Random().nextInt(11)-6;
							}
						}
						switch(j){
							case 0:
								//判断小圆是否出了屏幕,以下皆如此
								if(false==(mv.up_y[i]>h||(mv.up_x[i]>w||mv.up_x[i]<0))){
									mv.up_x[i]+=wx[j][i];
									mv.up_y[i]+=hy[j][i];
								}
								else{//出了就把小圆复位，并重新得到随机的速度,以下皆如此
									mv.up_x[i]=new Random().nextInt(w)+0;
									mv.up_y[i]=-5;
									av[j][i]=false;
								}
								break;
							case 1:
								if(false==(mv.under_y[i]<0||(mv.under_x[i]>w||mv.under_x[i]<0))){
									mv.under_x[i]+=wx[j][i];
									mv.under_y[i]-=hy[j][i];
								}
								else{
									mv.under_x[i]=new Random().nextInt(w);
									mv.under_y[i]=h+5;
									av[j][i]=false;
								}
								break;
							case 2:
								if(false==(mv.left_y[i]>h||(mv.left_x[i]>w||mv.left_y[i]<0))){
									mv.left_x[i]+=wx[j][i];
									mv.left_y[i]+=hy[j][i];
								}
								else{
									mv.left_y[i]=new Random().nextInt(h);
									mv.left_x[i]=-5;
									av[j][i]=false;
								}
								break;
							case 3:
								if(false==(mv.right_y[i]>h||(mv.right_y[i]<0||mv.right_x[i]<0))){
									mv.right_x[i]-=wx[j][i];
									mv.right_y[i]+=hy[j][i];
								}
								else{
									mv.right_y[i]=new Random().nextInt(h);
									mv.right_x[i]=w+5;
									av[j][i]=false;
								}
								break;
						}
						mv.invalidate();}}
	}
}
